# my-elearning
e-learning django app (django, python3)
[![Django CI](https://github.com/delitamakanda/elearning/actions/workflows/django.yml/badge.svg?branch=master)](https://github.com/delitamakanda/elearning/actions/workflows/django.yml)

## TODO
* Nice layout
* Login via Google
* ~~API~~
* ~~Celery worker~~
* ~~Reset Password~~
* ~~Search Form~~

start celery

```bash
celery -A myelearning  worker -l info -B
```