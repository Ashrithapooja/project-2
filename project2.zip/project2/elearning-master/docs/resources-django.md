
* https://tailwindui.com/components
* https://vimeo.com/393580241/82c6d7c5f6
* https://tailwindui.com/page-examples/detail-view-01
* https://tailwindui.com/page-examples/landing-page-01
* https://florian-dahlitz.de/blog/build-a-markdown-to-html-conversion-pipeline-using-python
* https://dohliam.github.io/dropin-minimal-css/
* https://github.com/xz/new.css#Customizing
* https://www.mattlayman.com/blog/2020/tailwind-django-heroku/
* https://tailblocks.cc/

1. https://testdriven.io/blog/django-performance-testing/
2. https://codyhouse.co/blog/post/multi-line-text-background
3. https://www.quora.com/How-can-I-implement-a-Django-notification-system-Please-with-example-code
4. https://css-tricks.com/building-a-conference-schedule-with-css-grid/
5. https://webkit.org/blog/8840/dark-mode-support-in-webkit/
6. https://realpython.com/get-started-with-django-1/
